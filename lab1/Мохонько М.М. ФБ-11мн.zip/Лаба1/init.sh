#! /bin/bash

mkdir obj
mkdir prof