class Settings():
    CRYPTO_RSA_KEY_LEN = 2048
    NUM_TESTS = 1000
    MESSAGE = 'hello'